package com.fc.fcxx;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FcxxApplication {

	public static void main(String[] args) {
		SpringApplication.run(FcxxApplication.class, args);
	}

}
