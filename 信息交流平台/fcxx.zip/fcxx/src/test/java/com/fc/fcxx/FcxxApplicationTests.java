package com.fc.fcxx;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FcxxApplicationTests {

	@Test
	void contextLoads() {
	}

}
